import java.util.ArrayList;

public class Train {
    private ArrayList<Customer> custList;
    private int stops;
    private int madeStops;
    private int currTime;

    // Constructor with stops and custList parameters
    public Train(int stops, ArrayList<Customer> custList) {
        this.stops = stops;
        this.custList = custList;
        this.madeStops = 0;
        this.currTime = 0;
    }

    // Getter and Setter methods for custList, stops, madeStops, and currTime (if needed)

    // Method to simulate the train
    public void simulate() {
        // Implementation for simulating the train
        // You can add logic to update custList, stops, madeStops, and currTime
    }

    // Method to display stops
    public void displayStops() {
        // Implementation for displaying stops
        // You can use custList, stops, madeStops, and currTime to display relevant information
    }
}

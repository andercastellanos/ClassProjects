import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Simulator {
    private int stops;

    public int getStopsFromUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter number of stops the train has on its route (must be greater than 1):");
        int stops = 0;
        boolean validInput = false;

        while (!validInput) {
            try {
                stops = Integer.parseInt(scanner.nextLine());
                if (stops > 1) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input, try again");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, try again");
            }
        }

        this.stops = stops;
        return stops;
    }

    public File getInputFile() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter absolute path for data file or for default (C:/train/customer-data.txt) press Enter:");

        String filePath = scanner.nextLine();
        File file = new File(filePath);

        while (!file.exists()) {
            System.out.println("File not found, try again.");
            filePath = scanner.nextLine();
            file = new File(filePath);
        }

        return file;
    }

    public ArrayList<Customer> checkFile(int stops, File file) {
        ArrayList<Customer> customers = new ArrayList<>();

        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split("\\s+");

                if (parts.length == 4) {
                    try {
                        int id = Integer.parseInt(parts[0]);
                        int arrival = Integer.parseInt(parts[1]);
                        int enter = Integer.parseInt(parts[2]);
                        int exit = Integer.parseInt(parts[3]);

                        if (id < 0 || arrival < 0 || enter < 1 || exit < 1 || exit > stops) {
                            System.out.println("Data in input file is not correct. Try again.");
                            return null;
                        }

                        customers.add(new Customer(id, arrival, enter, exit));
                    } catch (NumberFormatException e) {
                        System.out.println("Each line must have four integers. Try again.");
                        return null;
                    }
                } else {
                    System.out.println("Each line must have four integers. Try again.");
                    return null;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Try again.");
            return null;
        }

        return customers;
    }

    public void run(int stops, ArrayList<Customer> customers) {
        // Implement the simulation logic
        // You can use the stops and customers to simulate the train journey
    }

    public static void main(String[] args) {
        // Implement the main method logic
        // You can use the other methods to set up the simulation
    }
}


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Simulator {

    public int getStopsFromUser() {
        Scanner scanner = new Scanner(System.in);
        int stops = 0;
        boolean validInput = false;

        while (!validInput) {
            try {
                System.out.println("Enter number of stops the train has on its route (must be greater than 1):");
                stops = Integer.parseInt(scanner.nextLine());
                if (stops > 1) {
                    validInput = true;
                } else {
                    System.out.println("Invalid input, try again\n");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, try again\n");
            }
        }

        return stops;
    }

    public File getInputFile() {
        Scanner scanner = new Scanner(System.in);
        String filePath = "";
        File file = new File(filePath);

        while (!file.exists()) {
            System.out.println("Enter absolute path for data file or for default (C:/train/customer-data.txt) press Enter:");
            filePath = scanner.nextLine();
            file = new File(filePath);

            if (filePath.equals("")) {
                file = new File("C:/train/customer-data.txt");
            }

            if (!file.exists()) {
                System.out.println("File not found, try again.\n");
            }
        }

        return file;
    }

    public ArrayList<Customer> checkFile(int stops, File file) {
        ArrayList<Customer> list = new ArrayList<>();

        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split("\\s+");

                if (parts.length == 4) {
                    try {
                        int id = Integer.parseInt(parts[0]);
                        int arrival = Integer.parseInt(parts[1]);
                        int enter = Integer.parseInt(parts[2]);
                        int exit = Integer.parseInt(parts[3]);

                        if (id < 1 || arrival < 1 || enter < 1 || exit < 1 || enter > stops || exit > stops || enter == exit) {
                            System.out.println("Data in input file is not correct. Try again.");
                            return null;
                        }

                        list.add(new Customer(id, arrival, enter, exit));
                    } catch (NumberFormatException e) {
                        System.out.println("Each line must have four integers. Try again.");
                        return null;
                    }
                } else {
                    System.out.println("Each line must have four integers. Try again.");
                    return null;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Try again.\n");
            return null;
        }

        for (int i = 0; i < list.size() - 1; i++) {
            for (int j = i + 1; j < list.size(); j++) {

                if (list.get(i).getId() == list.get(j).getId()) {
                    System.out.println("Data in input file is not correct. Try again.");
                    return null;
                }
            }
        }

        return list;
    }

    public void run(int stops, ArrayList<Customer> custList) {
        Train train = new Train(stops, custList);
        train.simulate();
        train.displayStops();
    }

    public static void main(String[] args) {
        Simulator sim = new Simulator();

        ArrayList<Customer> custList = null;

        int stops = sim.getStopsFromUser();

        while (custList == null) {
            File file = sim.getInputFile();
            custList = sim.checkFile(stops, file);
        }

        sim.run(stops, custList);
    }
}

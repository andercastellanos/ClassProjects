
public class Customer {

    // Attributes
    private int id;
    private int arrival;
    private int enter;
    private int exit;
    private int status;

    // Constants
    public static final int CUST_NOT_PROCESSED = 0; // Customer has not been processed.
    public static final int CUST_ENTERED = 1; // Customer entered the train.
    public static final int CUST_EXITED = 2; // Customer exited the train and is done processing.

    // Constructor
    public Customer(int custId, int arrivalTime, int enterStop, int exitStop) {

        if (custId < 1 || arrivalTime < 1 || enterStop < 1 || exitStop < 1 || enterStop == exitStop) {
            throw new IllegalArgumentException("Values are not within the expected range.");
        }
        
        this.id = custId;
        this.arrival = arrivalTime;
        this.enter = enterStop;
        this.exit = exitStop;
        this.status = CUST_NOT_PROCESSED;
    }

    // Setter method
    public void setStatus(int status) {
        if (status < CUST_NOT_PROCESSED || status > CUST_EXITED) {
            throw new IllegalArgumentException("Status is not within the expected range.");
        }
        
        this.status = status;
    }

    // Getter methods
    public int getStatus() {
        return this.status;
    }

    public int getId() {
        return this.id;
    }

    public int getArrival() {
        return this.arrival;
    }

    public int getEnter() {
        return this.enter;
    }

    public int getExit() {
        return this.exit;
    }
}
